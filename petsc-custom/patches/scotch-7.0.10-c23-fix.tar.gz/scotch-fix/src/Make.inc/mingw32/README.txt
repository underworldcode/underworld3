These three script files can be used to create a Windows DLL from the
PT-Scotch library on a MinGW32 system. They are intended to be called 
directly from the src/Make.inc/mingw32 directory and produce results
in the lib directory.

The first two ones must be called from a Unix-like shell window.
The last one must be called from a MSDOS-like command window.

These scripts are intended only as examples. They must be adapted to
reflect your environment, in particular library path and library name.

They have been provided by Yves Secretan (yves.secretan@ete.inrs.ca)
and are licensed under the CeCILL-C libre/free license.
